<?php
    ob_start();

    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // লগইন করা না থাকলে তাকে লগইন পেজে রিডাইরেক্ট করে দেওয়া হবে
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_login_permission']) || $_SESSION['user_login_permission'] !== true) {
        header("Location: ../login.php"); // আপনার লগইন পেজের ফাইল পাথটি সঠিকভাবে মিলিয়ে নিন
        exit();
    }
    include 'includes/header.php'; 
?>

    <!-- MAIN BODY WORKSPACE (INDEPENDENT SCROLL LAYOUT) -->
    <div class="flex-1 flex overflow-hidden relative">
        <?php include 'includes/sidebar.php'; ?>    

        <!-- MAIN CONTENT AREA -->
        <main class="flex-1 overflow-y-auto flex flex-col justify-between bg-slate-50">
            <div class="p-4 sm:p-6 lg:p-8 space-y-6">
                <?php
                // GET মেথড থেকে page প্যারামিটার নেওয়া (ডিফল্ট: dashboard)
                $page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

                // Allowed routes setup
                switch ($page) {
                    case 'dashboard':
                        $filePath = 'pages/dashboard.php';
                        break;
                        
                    case 'donation':
                        $filePath = 'pages/donation.php';
                        break;

                    case 'volunteers':
                        $filePath = 'pages/volunteers.php';
                        break;

                    case 'events':
                        $filePath = 'pages/events.php';
                        break;

                    case 'expense':
                        $filePath = 'pages/finance_expenses.php';
                        break;

                    case 'report':
                        $filePath = 'pages/report.php';
                        break;

                    case 'logout':
                        $filePath = 'pages/logout.php'; 
                        break;

                    case 'view_member':
                        $filePath = 'pages/view_member.php';
                        break;

                    case 'certificates':
                        $filePath = 'pages/certificates.php';
                        break;

                    case 'inventory':
                        $filePath = 'pages/inventory.php';
                        break;

                    case 'tasks':
                        $filePath = 'pages/tasks_management.php';
                        break;

                    case 'notice_board':
                        $filePath = 'pages/notice_board.php';
                        break;

                    case 'meetings':
                        $filePath = 'pages/meetings.php';
                        break;

                    case 'settings':
                        $filePath = 'pages/settings.php';
                        break;

                    case 'my_donation':
                        $filePath = 'pages/my_donation.php';
                        break;

                    case 'my_certificates':
                        $filePath = 'pages/my_certificates.php';
                        break;

                    default:
                        $filePath = 'pages/404.php';
                        break;
                }

                // ফাইলটি ফোল্ডারে থাকলে include করবে, না থাকলে Error দেখাবে
                if (file_exists($filePath)) {
                    include $filePath;
                } else {
                    include 'pages/404.php';
                }
                ?>
            </div>

            <!-- FOOTER SECTION -->
            <footer class="bg-white border-t border-slate-200/80 py-4 px-6">
                <div class="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
                    <p>© <?php echo date('Y'); ?> <span class="font-semibold text-slate-700"><a href="https://bishwas.org" target="_blank" class="hover:text-emerald-600 transition-colors"><?php echo isset($site_title) ? $site_title : 'Bishwas'; ?></a></span>. All rights reserved.</p>
                    <div class="flex items-center gap-4">
                        <a href="#" class="hover:text-emerald-600 transition-colors">Privacy Policy</a>
                        <a href="#" class="hover:text-emerald-600 transition-colors">Terms of Service</a>
                        <a href="#" class="hover:text-emerald-600 transition-colors">Support</a>
                    </div>
                </div>
            </footer>
        </main>
    </div>

<?php include 'includes/footer.php'; ?>